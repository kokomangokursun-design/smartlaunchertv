GlassTV - launcher Android TV (liquid glass + panneau Spotify)
1. Ouvre le dossier dans Android Studio, laisse Gradle synchroniser, puis Build > Build APK.
2. Sur la TV : active le debogage ADB, puis  adb connect IP_TV  et  adb install app-debug.apk
3. Acces Spotify : lance GlassTV et appuie sur "Autoriser la lecture en cours". Si l'ecran n'existe pas :
   adb shell cmd notification allow_listener com.example.glasstv/com.example.glasstv.MediaListener
4. Google TV (touche Home) : adb shell pm disable-user --user 0 com.google.android.apps.tv.launcherx
   (retour arriere : pm enable ...)
