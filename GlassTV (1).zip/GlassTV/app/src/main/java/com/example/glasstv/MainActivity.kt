package com.example.glasstv

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

// Sert uniquement à obtenir l'accès aux sessions média (Spotify, YouTube Music...).
class MediaListener : NotificationListenerService()

class MainActivity : Activity() {
    // Apps affichées en premier (modifie à ta guise).
    private val pinned = listOf("com.google.android.youtube.tv", "com.spotify.tv.android", "com.stremio.one", "com.netflix.ninja")
    private val h = Handler(Looper.getMainLooper())
    private val comp by lazy { ComponentName(this, MediaListener::class.java) }
    private lateinit var msm: MediaSessionManager
    private var ctrl: MediaController? = null
    private var watching = false
    private var dur = 0L

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(m: MediaMetadata?) = meta(m)
        override fun onPlaybackStateChanged(s: PlaybackState?) = state()
    }
    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
    private val tick = object : Runnable {
        override fun run() { progress(); if (ctrl != null) h.postDelayed(this, 500) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        msm = getSystemService(MediaSessionManager::class.java)
        buildApps()
        findViewById<View>(R.id.prev).setOnClickListener { ctrl?.transportControls?.skipToPrevious() }
        findViewById<View>(R.id.next).setOnClickListener { ctrl?.transportControls?.skipToNext() }
        findViewById<View>(R.id.play).setOnClickListener {
            ctrl?.let { if (it.playbackState?.state == PlaybackState.STATE_PLAYING) it.transportControls.pause() else it.transportControls.play() }
        }
        findViewById<View>(R.id.perm).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            catch (e: Exception) { Toast.makeText(this, "Accorde l'accès via ADB (voir README)", Toast.LENGTH_LONG).show() }
        }
        listOf(R.id.prev, R.id.play, R.id.next, R.id.perm).forEach { glow(findViewById(it)) }
    }

    override fun onResume() {
        super.onResume()
        val ok = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        findViewById<View>(R.id.perm).visibility = if (ok) View.GONE else View.VISIBLE
        if (!ok) return
        try {
            if (!watching) { msm.addOnActiveSessionsChangedListener(sessions, comp); watching = true }
            pick(msm.getActiveSessions(comp))
        } catch (e: SecurityException) { }
    }

    override fun onPause() {
        super.onPause()
        if (watching) { msm.removeOnActiveSessionsChangedListener(sessions); watching = false }
        ctrl?.unregisterCallback(cb); ctrl = null; h.removeCallbacks(tick)
    }

    @Deprecated("Le launcher ne se ferme pas")
    override fun onBackPressed() { }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull { it.packageName.contains("spotify") } ?: list?.firstOrNull()
        if (c?.sessionToken != ctrl?.sessionToken) {
            ctrl?.unregisterCallback(cb); ctrl = c; c?.registerCallback(cb)
        }
        meta(ctrl?.metadata); state()
    }

    private fun meta(m: MediaMetadata?) {
        findViewById<TextView>(R.id.title).text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        findViewById<TextView>(R.id.artist).text =
            m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        findViewById<ImageView>(R.id.art).setImageBitmap(art)
        dur = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
    }

    private fun state() {
        findViewById<View>(R.id.player).visibility = if (ctrl == null) View.GONE else View.VISIBLE
        val playing = ctrl?.playbackState?.state == PlaybackState.STATE_PLAYING
        findViewById<ImageView>(R.id.play).setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        h.removeCallbacks(tick); if (ctrl != null) tick.run()
    }

    private fun progress() {
        val s = ctrl?.playbackState ?: return
        var p = s.position
        if (s.state == PlaybackState.STATE_PLAYING) p += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
        p = p.coerceIn(0L, if (dur > 0) dur else maxOf(p, 0L))
        findViewById<ProgressBar>(R.id.bar).progress = if (dur > 0) (p * 1000 / dur).toInt() else 0
        findViewById<TextView>(R.id.elapsed).text = fmt(p)
        findViewById<TextView>(R.id.total).text = fmt(dur)
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun glow(v: View) = v.setOnFocusChangeListener { x, f ->
        x.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(150).start()
    }

    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildApps() {
        val pm = packageManager
        fun q(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        val list = q(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { q(Intent.CATEGORY_LAUNCHER) }
            .filter { it.activityInfo.packageName != packageName }
            .sortedWith(compareBy({ pinned.indexOf(it.activityInfo.packageName).let { i -> if (i < 0) 99 else i } },
                { it.loadLabel(pm).toString().lowercase() }))
        val row = findViewById<LinearLayout>(R.id.apps)
        list.forEach { ri ->
            val pkg = ri.activityInfo.packageName
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(d(10), d(14), d(10), d(10)); isFocusable = true; isClickable = true
                setBackgroundResource(R.drawable.glass_sel)
                layoutParams = LinearLayout.LayoutParams(d(120), d(120)).apply { marginEnd = d(14) }
            }
            t.addView(ImageView(this).apply { setImageDrawable(ri.loadIcon(pm)); layoutParams = LinearLayout.LayoutParams(d(56), d(56)) })
            t.addView(TextView(this).apply {
                text = ri.loadLabel(pm); setTextColor(Color.WHITE); textSize = 13f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setPadding(0, d(8), 0, 0)
            })
            t.setOnClickListener {
                (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))?.let { startActivity(it) }
            }
            glow(t); row.addView(t)
        }
        row.getChildAt(0)?.requestFocus()
    }
}
